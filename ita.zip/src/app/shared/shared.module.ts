import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PostComponent } from '../post/post.component';
import { FormsModule } from '@angular/forms';
import { PostListComponent } from '../post-list/post-list.component';


@NgModule({
  declarations: [PostComponent, PostListComponent],
  imports: [
    CommonModule,
    FormsModule
  ],
  exports: [
    PostComponent, PostListComponent
  ]
})
export class SharedModule { }
