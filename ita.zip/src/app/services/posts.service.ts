import { Injectable } from '@angular/core';
import { Post } from '../models/post.model';
import { of, Observable } from 'rxjs';
import { map, tap } from 'rxjs/operators'
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PostsService {

  ROOT_URL = "https://www.reddit.com";
  API_URL = "/api/v1/"

  constructor(private http: HttpClient) { }

  public getPosts(subreddit = null): Observable<Post[]> {
    return this.http.get(`${this.ROOT_URL}/r/${subreddit || 'all'}/.json`).pipe(
      map((res: any) => this.extractPosts(res))
    )
  }

  private extractPosts(data): Post[] {
    var posts = [];
    data.data.children.forEach(post => {
      posts.push({
        subreddit: post.data.subreddit,
        authorFullname: post.data.author_fullname,
        title: post.data.title,
        subredditNamePrefix: post.data.subreddit_prefixed,
        thumbnailWidth: post.data.thumbnail_width,
        thumbnail: post.data.thumbnail,
        created: post.data.created,
        previewImage: post.data.preview?.images[0]?.source?.url.replace('amp;s', 's')
      })
    });
    return posts;
  }
}
