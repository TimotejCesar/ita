import { TestBed, getTestBed, async, inject } from '@angular/core/testing';
import { Post } from '../models/post.model'
import { PostsService } from './posts.service';
import { HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import {HttpClientModule} from '@angular/common/http';

describe('PostsService', () => {

  let service: PostsService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [PostsService]
    });

    service = TestBed.get(PostsService);
    httpMock = TestBed.get(HttpTestingController);
  });

  it('should be created', () => {
    expect(TestBed.get(PostsService)).toBeTruthy();
  });

  it('should return an Observable<Post[]>', () => {
    service.getPosts().subscribe(
      (posts: Post[]) => {
        expect(posts[0].title).toEqual('title1');
        expect(posts[0].subreddit).toEqual('funny');

        expect(posts[1].title).toEqual('title2');
        expect(posts[1].subreddit).toEqual('memes');
      }
    )

    const req = httpMock.expectOne(`https://www.reddit.com/r/all/.json`);
    expect(req.request.method).toBe('GET');

    req.flush({
      data: {
        children: [
          {
            data: {
              title: 'title1',
              subreddit: 'funny'
            }
          },
          {
            data: {
              title: 'title2',
              subreddit: 'memes'
            }
          }
        ]
      }
    })

    httpMock.verify();
  })

  it('with subreddit parameter should return an Observable<Post[]> where the posts have the given subreddit', () => {
    service.getPosts('memes').subscribe(
      (posts: Post[]) => {
        expect(posts[0].title).toEqual('title1');
        expect(posts[0].subreddit).toEqual('memes');

        expect(posts[1].title).toEqual('title2');
        expect(posts[1].subreddit).toEqual('memes');
      }
    )

    const req = httpMock.expectOne(`https://www.reddit.com/r/memes/.json`);
    expect(req.request.method).toBe('GET');

    req.flush({
      data: {
        children: [
          {
            data: {
              title: 'title1',
              subreddit: 'memes'
            }
          },
          {
            data: {
              title: 'title2',
              subreddit: 'memes'
            }
          }
        ]
      }
    })

    httpMock.verify();
  })
});
