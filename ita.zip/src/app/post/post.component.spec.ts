import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PostComponent } from './post.component';

describe('PostComponent', () => {
  let component: PostComponent;
  let fixture: ComponentFixture<PostComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PostComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should render title', () => {
    component.post = {
      title: "Title"
    }
    fixture.detectChanges();
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('.title').textContent).toContain('Title');
  })

  it('should render preview image', () => {
    component.post = {
      previewImage: "https://nikonrumors.com/wp-content/uploads/2019/10/Nikon-Z-Noct-Nikkor-58mm-f0.95-lens-sample-photos-4.jpg"
    }
    fixture.detectChanges();
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('.preview img').src).toContain("https://nikonrumors.com/wp-content/uploads/2019/10/Nikon-Z-Noct-Nikkor-58mm-f0.95-lens-sample-photos-4.jpg")
  })

  it('should render subreddit', () => {
    component.post = {
     subreddit: "memes"
    }
    fixture.detectChanges();
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('.subreddit').textContent).toContain("memes")
  })
});
