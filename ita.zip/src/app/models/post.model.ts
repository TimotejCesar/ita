export interface Post {
  subreddit?: string;
  authorFullname?: string;
  title?: string;
  subredditNamePrefix?: string;
  thumbnailWidth?: number;
  thumbnail?: string;
  created?: number;
  previewImage?: string;
}
